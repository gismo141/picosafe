<?php

class Settings
{

  function Settings(&$app)
  {
    $this->app=&$app; 
  
    $this->app->ActionHandlerInit($this);

    $this->app->ActionHandler("list","SettingsList");
    $this->app->ActionHandler("sshstart","SettingsSSHStart");
    $this->app->ActionHandler("sshstop","SettingsSSHStop");
  
    $this->app->DefaultActionHandler("list");

    
    $this->app->Tpl->ReadTemplatesFromPath("./pages/content/");

    $this->app->ActionHandlerListen(&$app);
  }



  function SettingsList()
  {
    $submit = $this->app->Secure->GetPOST("submit");

    date_default_timezone_set('UTC');
    if($submit!="")
    {
      $datum = $this->app->Secure->GetPOST("datum");
      $stunde = $this->app->Secure->GetPOST("stunde");
      $minute = $this->app->Secure->GetPOST("minute");
      $sekunde = $this->app->Secure->GetPOST("sekunde");

      $arrdatum = split('\.',$datum);

      $timestamp = mktime($stunde,$minute,$sekunde,$arrdatum[1],$arrdatum[0],$arrdatum[2]);
   //   $this->app->lua->SingleCommand("rtc_set_timestamp($timestamp)");
//      echo "date -u -s \"{$arrdatum[2]}-{$arrdatum[1]}-$arrdatum[0] {$stunde}:{$minute}:{$sekunde}\"";
      exec("date -u -s \"{$arrdatum[2]}-{$arrdatum[1]}-$arrdatum[0] {$stunde}:{$minute}:{$sekunde}\"");
      //exec("date -u -s \"{$arrdatum[2]}-{$arrdatum[1]}-$arrdatum[0] {$arruhrzeit[0]}:{$arruhrzeit[1]}:{$arruhrzeit[2]}\"");

    }

    // Die Standard-Zeitzone, die verwendet werden soll, setzen.
    $datum = date('d.m.Y'); 
    $stunde = date('H'); 
    $minute = date('i'); 
    $sekunde = date('s'); 
  
    $this->app->Tpl->Set(DATUM,$datum);
    $this->app->Tpl->Set(STUNDE,$stunde);
    $this->app->Tpl->Set(MINUTE,$minute);
    $this->app->Tpl->Set(SEKUNDE,$sekunde);
    $this->app->Tpl->Set(UEBERSCHRIFT,"Einstellungen");
    $this->app->Tpl->Parse(PAGE,"settings.tpl");
  }
  
  function SettingsSSHStart()                                                                                                                          
  {                                                   
    exec("/opt/fred/init.d/sshd start");                       
    $this->SettingsList();
  } 
  
  function SettingsSSHStop()
  {
    exec("/opt/fred/init.d/sshd stop");                            
    $this->SettingsList();         
  }    
  	                                                                                                                                                                                               

}
?>
