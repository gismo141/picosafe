<?php

class Ssh
{

  function Ssh(&$app)
  {
    $this->app=&$app;
        
    $this->app->ActionHandlerInit($this);
            
    $this->app->ActionHandler("list","SshList");
    $this->app->ActionHandler("table","SshTable");
                
    $this->app->DefaultActionHandler("list");
                    
    $this->app->Tpl->ReadTemplatesFromPath("./pages/content/");
                        
    $this->app->ActionHandlerListen(&$app);
  }
                              
    

  function SshList()
  {
		$this->app->Tpl->Parse(PAGE,"ssh_list.tpl");
	}


  function SshTable()
  {

    $result = $this->app->DB->SelectArr("SELECT account,description,externallogin,id FROM ssh");

    $iTotal=count($result);
		$iFilteredTotal="1";

		$output = array(
		"sEcho" => intval($this->app->Secure->GetGET("sEcho")),
		"iTotalRecords" => $iTotal,
		"iTotalDisplayRecords" => $iFilteredTotal,
		"aaData" => array()
		);

		foreach($result as $key=>$row)
    {
			$output['aaData'][] = $row;//array('name','descr','accout','id');	
    }

		echo json_encode( $output );
	
    exit;
  }

}
?>
                                            
