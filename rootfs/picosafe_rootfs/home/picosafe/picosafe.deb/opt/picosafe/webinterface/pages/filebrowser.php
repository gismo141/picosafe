<?php

class Filebrowser
{
  function Filebrowser(&$app)
  {
    $this->app=&$app; 
  
    $this->app->ActionHandlerInit($this);

    $this->app->ActionHandler('list', 'FilebrowserList');
  
    $this->app->DefaultActionHandler("list");

    $this->app->ActionHandlerListen(&$app);
  }

	function Sidebar()
	{
		$this->app->Tpl->Set('SIDEBAR_TITLE', 'Anwendungen');

		$sidebar = array('Windows 7' =>'index.php?module=apps&action=win7',
		                 'Secure Phone' =>'index.php?module=apps&action=secphone',
										 'Harddisk Crypt' => 'index.php?module=apps&action=harddiskcrypt',
										 'Intranet/VPN' => 'index.php?module=apps&action=vpn');

		$this->app->Core->BuildSidebar($sidebar);
	}

  function FilebrowserList()
  {
		$this->Sidebar();
		$path = $_GET['path'];
		
		$this->app->Tpl->Set('PATH', $path);

    $this->app->Tpl->Parse(PAGE, 'filebrowser_list.tpl');
  }
}
?>
